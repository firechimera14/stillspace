const BASE="http://127.0.0.1:47831";
const norm=r=>r.trim().toLowerCase().replace(/^https?:\/\//,"").replace(/^\*\./,"").replace(/\/+$/,"");
const toFilter=r=>{r=norm(r);return r?"||"+r+(r.includes("/")?"":"^"):""};
function match(url,r){try{const u=new URL(url),t=u.host.toLowerCase()+u.pathname,p=norm(r);if(!p)return false;if(p.includes("*")){const re=new RegExp("^(.*\\.)?"+p.replace(/[.+?^${}()|[\]\\]/g,"\\$&").replace(/\*/g,".*"));return re.test(t)}if(p.includes("/"))return t.startsWith(p)||(u.host.toLowerCase().endsWith("."+p.split("/")[0])&&t.includes(p.split("/")[0]+"/"+p.split("/").slice(1).join("/")));return u.host.toLowerCase()==p||u.host.toLowerCase().endsWith("."+p)}catch(e){return false}}
let was=false,busy=false,lastSync=0;
async function sync(){if(busy)return;busy=true;lastSync=Date.now();try{let st;try{st=await(await fetch(BASE+"/state",{cache:"no-store"})).json();fetch(BASE+"/ping",{method:"POST"}).catch(()=>{});await chrome.storage.local.set({ok:Date.now(),st:{active:!!st.active,rules:st.rules||[]}})}catch(e){const{ok=0}=await chrome.storage.local.get("ok");if(Date.now()-ok>120000)st={active:false,rules:[]};else return}
const list=[...new Set((st.active?st.rules:[]).map(toFilter).filter(Boolean))],old=(await chrome.declarativeNetRequest.getDynamicRules()).map(r=>r.id);
const addRules=list.map((f,i)=>({id:i+1,priority:1,action:{type:"redirect",redirect:{url:BASE+"/blocked?r="+encodeURIComponent(f.replace(/^\|\|/,"").replace(/\^$/,""))}},condition:{urlFilter:f,resourceTypes:["main_frame"]}}));
await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:old,addRules});
if(addRules.length&&!was){const tabs=await chrome.tabs.query({});tabs.forEach(t=>{const r=(st.rules||[]).find(x=>t.url&&match(t.url,x));if(r)chrome.tabs.update(t.id,{url:BASE+"/blocked?r="+encodeURIComponent(norm(r))})})}
was=addRules.length>0}finally{busy=false}}
chrome.webNavigation.onBeforeNavigate.addListener(d=>{if(d.frameId===0&&Date.now()-lastSync>2000)sync()});
chrome.webNavigation.onErrorOccurred.addListener(async d=>{if(d.frameId!==0||!/^https?:/.test(d.url))return;await sync();const{st}=await chrome.storage.local.get("st");if(st&&st.active){const r=(st.rules||[]).find(x=>match(d.url,x));if(r)chrome.tabs.update(d.tabId,{url:BASE+"/blocked?r="+encodeURIComponent(norm(r))})}});
chrome.alarms.create("sync",{periodInMinutes:.5});chrome.alarms.onAlarm.addListener(sync);chrome.runtime.onStartup.addListener(sync);chrome.runtime.onInstalled.addListener(sync);
chrome.tabs.onUpdated.addListener((id,ch)=>{if(ch.status=="loading"&&Date.now()-lastSync>4000)sync()});sync();
if(typeof module!="undefined")module.exports={toFilter,match,norm,sync};
